#!/usr/bin/env python3
"""
backup.py — puxa backups dos servidores para o disco local (NAS) e escreve o resultado em JSON.

Corre no agente (LXC no Proxmox). Nunca é chamado de fora: o agente liga sempre para fora.
Todos os segredos vêm do config.yaml gerado pelo agent_sync.py a partir do secrets.yaml local.

Uso:
    python3 backup.py --config config.yaml --results-json results.json [--only nome] [--dry-run]

Layout no disco:
    <backup_root>/<nome-do-servidor>/<AAAA-MM-DD_HHMM>/{ficheiros...}
    <backup_root>/<nome-do-servidor>/latest -> <AAAA-MM-DD_HHMM>
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    print("Falta o pyyaml. Corre: pip install pyyaml requests", file=sys.stderr)
    raise SystemExit(2)

log = logging.getLogger("backup")

SSH_BASE_OPTS = [
    "-o", "BatchMode=yes",
    "-o", "StrictHostKeyChecking=accept-new",
    "-o", "ConnectTimeout=20",
    "-o", "ServerAliveInterval=30",
    "-o", "ServerAliveCountMax=10",
]

STAMP_RE = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{4}(_\d+)?$")


# --------------------------------------------------------------------------
# Utilitários
# --------------------------------------------------------------------------

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def human_size(num: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if num < 1024:
            return f"{num:.1f} {unit}"
        num /= 1024.0
    return f"{num:.1f} PB"


class BackupError(RuntimeError):
    """Falha num servidor — apanhada e reportada, nunca aborta o lote todo."""


# --------------------------------------------------------------------------
# SSH
# --------------------------------------------------------------------------

def ssh_command(server: dict) -> list[str]:
    """Constrói o prefixo do comando ssh para este servidor."""
    key = server.get("ssh_key")
    if not key:
        raise BackupError(
            f"sem chave SSH: nenhuma entrada em secrets.yaml para "
            f"'{server.get('agent_secret_ref') or server['name']}'"
        )
    if not Path(key).is_file():
        raise BackupError(f"chave SSH não encontrada em {key}")

    cmd = ["ssh", "-i", key, *SSH_BASE_OPTS]
    if server.get("port"):
        cmd += ["-p", str(server["port"])]
    if server.get("known_hosts"):
        cmd += ["-o", f"UserKnownHostsFile={server['known_hosts']}"]

    user = server.get("user") or "root"
    cmd.append(f"{user}@{server['host']}")
    return cmd


def ssh_check(server: dict, timeout: int = 30) -> None:
    """Verifica que o SSH funciona antes de tentar puxar gigabytes."""
    cmd = ssh_command(server) + ["--", "true"]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if proc.returncode != 0:
        raise BackupError(f"SSH falhou: {(proc.stderr or '').strip()[:300]}")


def ssh_capture(server: dict, remote_cmd: str, timeout: int = 120) -> str:
    """Corre um comando remoto curto e devolve o stdout."""
    cmd = ssh_command(server) + ["--", remote_cmd]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if proc.returncode != 0:
        raise BackupError(
            f"comando remoto falhou ({remote_cmd.split()[0]}): "
            f"{(proc.stderr or proc.stdout or '').strip()[:300]}"
        )
    return proc.stdout


def ssh_stream_to_file(server: dict, remote_cmd: str, dest: Path,
                       timeout: int | None = None) -> dict:
    """
    Corre um comando remoto que escreve para stdout e guarda esse stream em `dest`,
    calculando o sha256 pelo caminho. Nada toca no disco do servidor de origem.
    """
    cmd = ssh_command(server) + ["--", remote_cmd]
    digest = hashlib.sha256()
    total = 0

    dest.parent.mkdir(parents=True, exist_ok=True)
    stderr_file = tempfile.TemporaryFile()

    log.debug("stream: %s", remote_cmd)
    started = time.monotonic()

    with subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=stderr_file) as proc, \
            open(dest, "wb") as out:
        assert proc.stdout is not None
        while True:
            chunk = proc.stdout.read(1024 * 512)
            if not chunk:
                break
            out.write(chunk)
            digest.update(chunk)
            total += len(chunk)
            if timeout and (time.monotonic() - started) > timeout:
                proc.kill()
                raise BackupError(f"timeout ao transferir {dest.name}")
        rc = proc.wait()

    stderr_file.seek(0)
    err = stderr_file.read().decode("utf-8", "replace").strip()
    stderr_file.close()

    if rc != 0:
        dest.unlink(missing_ok=True)
        raise BackupError(f"falha ao gerar {dest.name}: {err[:300] or f'exit {rc}'}")

    if total == 0:
        dest.unlink(missing_ok=True)
        raise BackupError(f"{dest.name} veio vazio — {err[:200] or 'sem erro reportado'}")

    log.info("  %s — %s", dest.name, human_size(total))
    return {"file": dest.name, "bytes": total, "sha256": digest.hexdigest()}


# --------------------------------------------------------------------------
# Handlers por tipo de servidor
# --------------------------------------------------------------------------

def backup_plesk(server: dict, dest_dir: Path) -> list[dict]:
    """
    Backup de um domínio Plesk, transmitido para stdout — não ocupa disco no VPS
    (é isso que mata os backups do Plesk em servidores cheios).
    """
    domain = server.get("domain")
    if not domain:
        raise BackupError("servidor plesk sem 'Dominio a fazer backup' definido")

    extra = server.get("plesk_backup_args") or ""
    remote = (
        f"plesk bin pleskbackup --domains-name {shlex.quote(domain)} "
        f"{extra} --output-file=-"
    ).strip()

    safe = domain.replace("/", "_")
    return [ssh_stream_to_file(server, remote, dest_dir / f"{safe}.tar")]


def backup_wordpress(server: dict, dest_dir: Path) -> list[dict]:
    """Base de dados via wp-cli (ou mysqldump a partir do wp-config) + tar dos ficheiros."""
    wp_root = server.get("wp_root")
    if not wp_root:
        raise BackupError("servidor wordpress sem 'wp_root' definido")

    root = shlex.quote(wp_root)
    artifacts = []

    db_cmd = (
        f"cd {root} && "
        f"if command -v wp >/dev/null 2>&1; then "
        f"  wp db export - --single-transaction --quick --skip-plugins --skip-themes "
        f"     --allow-root 2>/dev/null | gzip -c; "
        f"else "
        f"  DB_NAME=$(php -r \"include '{wp_root}/wp-config.php'; echo DB_NAME;\"); "
        f"  DB_USER=$(php -r \"include '{wp_root}/wp-config.php'; echo DB_USER;\"); "
        f"  DB_PASS=$(php -r \"include '{wp_root}/wp-config.php'; echo DB_PASSWORD;\"); "
        f"  DB_HOST=$(php -r \"include '{wp_root}/wp-config.php'; echo DB_HOST;\"); "
        f"  MYSQL_PWD=\"$DB_PASS\" mysqldump -h \"${{DB_HOST%%:*}}\" -u \"$DB_USER\" "
        f"     --single-transaction --quick --default-character-set=utf8mb4 \"$DB_NAME\" | gzip -c; "
        f"fi"
    )
    artifacts.append(ssh_stream_to_file(server, db_cmd, dest_dir / "database.sql.gz"))

    files_cmd = (
        f"tar czf - -C {root} "
        f"--exclude=./wp-content/cache "
        f"--exclude=./wp-content/uploads/backup* "
        f"--exclude=./wp-content/ai1wm-backups "
        f"--warning=no-file-changed ."
    )
    artifacts.append(ssh_stream_to_file(server, files_cmd, dest_dir / "files.tar.gz"))
    return artifacts


def backup_vps_laravel(server: dict, dest_dir: Path) -> list[dict]:
    """Base de dados lida do .env da app (ou do db_override) + tar da app e storage extra."""
    app_path = server.get("app_path")
    if not app_path:
        raise BackupError("servidor vps_laravel sem 'app_path' definido")

    app = shlex.quote(app_path)
    artifacts = []
    override = server.get("db_override") or {}

    if override.get("database"):
        db_cmd = (
            f"MYSQL_PWD={shlex.quote(str(override.get('password', '')))} "
            f"mysqldump -h {shlex.quote(str(override.get('host', '127.0.0.1')))} "
            f"-u {shlex.quote(str(override.get('username', 'root')))} "
            f"--single-transaction --quick --default-character-set=utf8mb4 "
            f"{shlex.quote(str(override['database']))} | gzip -c"
        )
    else:
        db_cmd = (
            f"set -a && . {app}/.env && set +a && "
            f"MYSQL_PWD=\"$DB_PASSWORD\" mysqldump -h \"${{DB_HOST:-127.0.0.1}}\" "
            f"-P \"${{DB_PORT:-3306}}\" -u \"$DB_USERNAME\" "
            f"--single-transaction --quick --default-character-set=utf8mb4 "
            f"\"$DB_DATABASE\" | gzip -c"
        )
    artifacts.append(ssh_stream_to_file(server, db_cmd, dest_dir / "database.sql.gz"))

    files_cmd = (
        f"tar czf - -C {app} "
        f"--exclude=./vendor --exclude=./node_modules "
        f"--exclude=./storage/framework/cache --exclude=./storage/framework/sessions "
        f"--exclude=./storage/framework/views --exclude=./storage/logs "
        f"--warning=no-file-changed ."
    )
    artifacts.append(ssh_stream_to_file(server, files_cmd, dest_dir / "app.tar.gz"))

    for idx, extra in enumerate(server.get("storage_paths") or [], start=1):
        safe_name = Path(extra.rstrip("/")).name or f"storage{idx}"
        cmd = f"tar czf - -C {shlex.quote(extra)} --warning=no-file-changed ."
        artifacts.append(
            ssh_stream_to_file(server, cmd, dest_dir / f"storage-{safe_name}.tar.gz")
        )

    return artifacts


def backup_cpanel(server: dict, dest_dir: Path) -> list[dict]:
    """
    cPanel ainda não implementado — o backup full por UAPI precisa de pedir, esperar
    e ir buscar, e neste momento não há nenhum servidor deste tipo no painel.
    """
    raise BackupError(
        "tipo 'cpanel' ainda não implementado neste agente — usa SSH/rsync ou pede para ser adicionado"
    )


HANDLERS = {
    "plesk": backup_plesk,
    "wordpress": backup_wordpress,
    "vps_laravel": backup_vps_laravel,
    "cpanel": backup_cpanel,
}


# --------------------------------------------------------------------------
# Retenção
# --------------------------------------------------------------------------

def sweep_stale_partials(server_dir: Path, older_than_hours: int = 24) -> None:
    """
    Limpa restos de execuções interrompidas (queda de rede, container reiniciado).
    Só mexe no que tem mais de um dia, para nunca apanhar uma execução em curso.
    """
    cutoff = time.time() - older_than_hours * 3600
    for leftover in server_dir.glob(".*.partial"):
        if leftover.is_dir() and leftover.stat().st_mtime < cutoff:
            log.info("  a limpar resto de execução interrompida: %s", leftover.name)
            shutil.rmtree(leftover, ignore_errors=True)


def prune(server_dir: Path, keep_days: int, keep_min_copies: int) -> None:
    """Apaga snapshots antigos, garantindo sempre um mínimo de cópias."""
    if not server_dir.is_dir():
        return

    snapshots = sorted(
        (d for d in server_dir.iterdir() if d.is_dir() and STAMP_RE.match(d.name)),
        key=lambda d: d.name,
        reverse=True,
    )

    keep_min_copies = max(int(keep_min_copies or 1), 1)
    cutoff = time.time() - (int(keep_days or 0) * 86400)

    for idx, snap in enumerate(snapshots):
        if idx < keep_min_copies:
            continue
        if not keep_days:
            continue
        if snap.stat().st_mtime < cutoff:
            log.info("  retenção: a apagar %s", snap.name)
            shutil.rmtree(snap, ignore_errors=True)


# --------------------------------------------------------------------------
# Execução de um servidor
# --------------------------------------------------------------------------

def run_server(server: dict, global_cfg: dict, dry_run: bool) -> dict:
    name = server["name"]
    stype = server.get("type", "")
    started = utc_now_iso()

    result = {
        "name": name,
        "type": stype,
        "success": False,
        "error": None,
        "started_at": started,
        "finished_at": None,
    }

    log.info("▶ %s (%s) — %s", name, stype, server.get("host"))

    try:
        handler = HANDLERS.get(stype)
        if handler is None:
            raise BackupError(f"tipo de servidor desconhecido: '{stype}'")

        ssh_check(server)

        if dry_run:
            log.info("  dry-run: SSH ok, nada foi transferido")
            result["success"] = True
            result["finished_at"] = utc_now_iso()
            return result

        backup_root = Path(global_cfg["backup_root"])
        server_dir = backup_root / name
        server_dir.mkdir(parents=True, exist_ok=True)
        sweep_stale_partials(server_dir)

        # Duas execuções no mesmo minuto não podem colidir no mesmo nome —
        # senão o rename final falha e fica lixo no NAS.
        stamp = datetime.now().strftime("%Y-%m-%d_%H%M")
        dest_dir = server_dir / stamp
        attempt = 1
        while dest_dir.exists():
            attempt += 1
            dest_dir = server_dir / f"{stamp}_{attempt}"

        partial = server_dir / f".{dest_dir.name}.partial"
        shutil.rmtree(partial, ignore_errors=True)
        partial.mkdir(parents=True, exist_ok=True)

        try:
            artifacts = handler(server, partial)

            total = sum(a["bytes"] for a in artifacts)
            manifest = {
                "server": name,
                "type": stype,
                "host": server.get("host"),
                "started_at": started,
                "finished_at": utc_now_iso(),
                "total_bytes": total,
                "artifacts": artifacts,
            }
            (partial / "manifest.json").write_text(
                json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
            )

            # Só agora o snapshot passa a existir com o nome final: um backup
            # interrompido nunca fica a parecer completo.
            partial.rename(dest_dir)
        except Exception:
            shutil.rmtree(partial, ignore_errors=True)
            # Não deixar uma pasta vazia no NAS por causa de um servidor que nunca correu
            try:
                server_dir.rmdir()
            except OSError:
                pass
            raise

        latest = server_dir / "latest"
        latest.unlink(missing_ok=True)
        try:
            latest.symlink_to(dest_dir.name, target_is_directory=True)
        except OSError:
            pass  # sistemas de ficheiros sem symlinks (CIFS mal montado) não são fatais

        retention = server.get("retention") or {}
        prune(
            server_dir,
            retention.get("keep_days", global_cfg.get("retention", {}).get("keep_days")),
            retention.get("keep_min_copies",
                          global_cfg.get("retention", {}).get("keep_min_copies")),
        )

        log.info("  ✓ OK — %s em %s", human_size(total), dest_dir.name)
        result["success"] = True

    except BackupError as exc:
        log.error("  ✗ %s", exc)
        result["error"] = str(exc)
    except subprocess.TimeoutExpired:
        log.error("  ✗ timeout")
        result["error"] = "timeout na ligação SSH"
    except Exception as exc:  # noqa: BLE001 - um servidor nunca derruba o lote
        log.exception("  ✗ erro inesperado")
        result["error"] = f"{type(exc).__name__}: {exc}"[:500]

    result["finished_at"] = utc_now_iso()
    return result


# --------------------------------------------------------------------------
# Guardas do disco de destino
# --------------------------------------------------------------------------

def assert_backup_root(global_cfg: dict) -> None:
    root = Path(global_cfg.get("backup_root", ""))
    if not root or str(root) in ("", "/"):
        raise SystemExit("backup_root não definido no config.")

    if global_cfg.get("require_mountpoint", True):
        if not root.exists():
            raise SystemExit(
                f"{root} não existe. O NAS está montado? "
                f"(require_mountpoint: false no agent.yaml desliga esta verificação)"
            )
        if not os.path.ismount(root):
            # Sem esta guarda, um NAS desmontado enche o disco do container em silêncio
            # e os backups ficam a apontar para o sítio errado.
            raise SystemExit(
                f"{root} não é um ponto de montagem — o NAS parece estar desmontado. "
                f"Nada foi feito."
            )

    root.mkdir(parents=True, exist_ok=True)
    if not os.access(root, os.W_OK):
        raise SystemExit(f"sem permissão de escrita em {root}")


# --------------------------------------------------------------------------
# Notificações
# --------------------------------------------------------------------------

def notify(global_cfg: dict, results: list[dict]) -> None:
    failed = [r for r in results if not r["success"]]
    cfg = global_cfg.get("notify") or {}

    if cfg.get("on_failure_only", True) and not failed:
        return

    lines = [
        f"{'✓' if r['success'] else '✗'} {r['name']}"
        + (f" — {r['error']}" if r["error"] else "")
        for r in results
    ]
    body = "\n".join(lines)
    subject = f"Backups: {len(results) - len(failed)} ok, {len(failed)} falhados"

    webhook = cfg.get("webhook") or {}
    if webhook.get("enabled") and webhook.get("url"):
        try:
            import requests
            requests.post(
                webhook["url"],
                json={"text": f"*{subject}*\n```{body}```"},
                timeout=15,
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("webhook falhou: %s", exc)

    sendmail = cfg.get("sendmail") or {}
    if sendmail.get("enabled") and sendmail.get("to"):
        try:
            subprocess.run(
                ["mail", "-s", subject, sendmail["to"]],
                input=body, text=True, timeout=30, check=False,
            )
        except FileNotFoundError:
            log.warning("sendmail pedido mas o comando 'mail' não existe neste container")


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description="Puxa backups dos servidores para o NAS.")
    parser.add_argument("--config", required=True, help="config.yaml gerado pelo agent_sync.py")
    parser.add_argument("--results-json", help="ficheiro onde escrever os resultados")
    parser.add_argument("--only", action="append", default=[],
                        help="limita a um servidor (pode repetir)")
    parser.add_argument("--dry-run", action="store_true",
                        help="testa só o SSH, não transfere nada")
    args = parser.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8")) or {}
    global_cfg = cfg.get("global") or {}
    servers = cfg.get("servers") or []

    logging.basicConfig(
        level=getattr(logging, str(global_cfg.get("logging", {}).get("level", "INFO")).upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(message)s",
        datefmt="%H:%M:%S",
    )

    if args.only:
        servers = [s for s in servers if s["name"] in args.only]

    if not servers:
        log.warning("Nenhum servidor a processar.")
        if args.results_json:
            Path(args.results_json).write_text(
                json.dumps({"results": [], "dry_run": args.dry_run}, ensure_ascii=False),
                encoding="utf-8")
        return 0

    if not args.dry_run:
        assert_backup_root(global_cfg)

    log.info("Servidores a processar: %d", len(servers))
    results = [run_server(s, global_cfg, args.dry_run) for s in servers]

    ok = sum(1 for r in results if r["success"])
    log.info("Resumo: ✓ %d   ✗ %d", ok, len(results) - ok)

    if args.results_json:
        Path(args.results_json).write_text(
            json.dumps({"results": results, "dry_run": args.dry_run},
                       indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    if not args.dry_run:
        notify(global_cfg, results)

    return 0 if ok == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
